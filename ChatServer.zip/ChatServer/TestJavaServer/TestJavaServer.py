import socket	
import random
import select
import sys
import ssl
import urllib.request as urllibReq

def broadcastData(message, client):
    client.send((message + "\r\n").encode());


host = "10.233.130.84"  #Change to computers IP address (open cmd - ipconfig - IPv4 Address)
port = 9000  #Make sure its some random large number (less than 37k) so its not used by another application
print(host)
player = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #creates the player socket
player.bind((host, port))	
player.listen(5)	

inputs = [player] #Accepts connections from predetermined sockets
addressDictionary = {}



while inputs:   
    
    (read, write, excep) = select.select(inputs, [], [])
    for sock in read: #procceses each incoming socket
        try:
            if sock is player:  #Accepts connection from player socket and creates random num
                (client, address) = player.accept()        
                print("User Connected")      
                inputs.append(client)
                addressDictionary[client] = client                
               # print(message);  
            else:
                message = sock.recv(1024).decode();              
                if (message != ''):
                    print(message)      
                    for i in addressDictionary:                                       
                        i.send((message + "\r\n").encode());    
        except:   
            print("User Disconnected") 
            del addressDictionary[sock]                 
            inputs.remove(sock)              
            sock.close()       

